export default {
	'import-kit': '/import/process',
};
